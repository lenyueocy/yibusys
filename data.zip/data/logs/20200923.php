<?php exit;?>	2020-09-23 23:32:20 debug :
------------
String:
account-ticket

