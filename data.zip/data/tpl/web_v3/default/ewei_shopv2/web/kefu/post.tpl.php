<?php defined('IN_IA') or exit('Access Denied');?><?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('_header', TEMPLATE_INCLUDEPATH)) : (include template('_header', TEMPLATE_INCLUDEPATH));?>


<div class="page-header">
	当前位置：<span class="text-primary"><?php  if(!empty($item['id'])) { ?>编辑<?php  } else { ?>添加<?php  } ?>医生 <small><?php  if(!empty($item['id'])) { ?>修改【<?php  echo $item['name'];?>】<?php  } ?></small></span>
</div>

<div class="page-content">
    <?php if(cv('doctor.add')) { ?>
    <div class="page-sub-toolbar">
        <a class="btn btn-primary btn-sm" href="<?php  echo webUrl('doctor/add')?>">添加医生</a>
    </div>
    <?php  } ?>
    <form <?php if( ce('doctor.add' ,$item) ) { ?>action="" method="post"<?php  } ?> class="form-horizontal form-validate" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?php  echo $item['id'];?>" />
 

            <div class="form-group">
                <label class="col-lg control-label must">选择会员</label>
                <div class="col-sm-9 col-xs-12">
                    <?php if( ce('doctor' ,$item) ) { ?>
                       <?php  echo tpl_selector('openid',array('key'=>'openid', 'required'=>true, 'text'=>'nickname', 'thumb'=>'avatar','placeholder'=>'昵称/姓名/手机号','buttontext'=>'选择会员 ', 'items'=>$saler,'url'=>webUrl('member/query',array('no_wa'=>1))))?>
                    <!--<span class="help-block">暂时不支持选择小程序的会员</span>-->

                    <?php  } else { ?>
                         <?php  if(!empty($saler)) { ?>
                         <span class='help-block'><img  style="width:100px;height:100px;border:1px solid #ccc;padding:1px" src="<?php  echo tomedia($saler['avatar'])?>"/><br/>
                             <?php  if(!empty($saler)) { ?><?php  echo $saler['nickname'];?>/<?php  echo $saler['realname'];?>/<?php  echo $saler['mobile'];?><?php  } ?></span>
                        <?php  } ?>
                    <?php  } ?>

                </div>
            </div>


            <div class="form-group">
                <label class="col-lg control-label must">客服名称</label>
                <div class="col-sm-9 col-xs-12">
                    <?php if( ce('doctor.index' ,$item) ) { ?>
                    <input type="text" name="name" class="form-control" value="<?php  echo $item['name'];?>" data-rule-required='true'/>
                    <?php  } else { ?>
                    <div class='form-control-static'><?php  echo $item['name'];?></div>
                    <?php  } ?>
                </div>
            </div>

            <div class="form-group">
                <label class="col-lg control-label must">客服头像</label>
                <div class="col-sm-9 col-xs-12">
                    <?php if( ce('doctor' ,$item) ) { ?>
                    <?php  echo tpl_form_field_image('avatar',$item['avatar'])?>
                    <?php  } else { ?>
                    <?php  if(!empty($item['avatar'])) { ?>
                    <a href='<?php  echo tomedia($item['avatar'])?>' target='_blank'>
                    <img src="<?php  echo tomedia($item['avatar'])?>" style='width:100px;border:1px solid #ccc;padding:1px'/>
                    </a>
                    <?php  } ?>
                    <?php  } ?>
                </div>
            </div>

            <!--<div class="form-group">
                <label class="col-lg control-label must">手机号</label>
                <div class="col-sm-9 col-xs-12">
                    <?php if( ce('store.saler' ,$item) ) { ?>
                    <input type="text" name="mobile" class="form-control" value="<?php  echo $item['mobile'];?>" />
                    <?php  } else { ?>
                    <div class='form-control-static'><?php  echo $item['mobile'];?></div>
                    <?php  } ?>
                </div>
            </div>-->

             <!--<div class="form-group">
                <label class="col-lg control-label must">所属科室</label>
                <div class="col-sm-9 col-xs-12">
                    <?php if( ce('doctor' ,$item) ) { ?>
                        <select name='departmentid' class="form-control select2" style='width:605px;' >
                            <?php  if(is_array($department)) { foreach($department as $d) { ?>
                            <option value="<?php  echo $d['id'];?>" <?php  if($item['departmentid']==$d['id']) { ?>selected<?php  } ?> ><?php  echo $d['name'];?></option>
                            <?php  } } ?>
                        </select>
                    <?php  } else { ?>
                        <div class='form-control-static'><?php  if(empty($store['storename'])) { ?>无所属门店<?php  } else { ?><?php  echo $store['storename'];?><?php  } ?></div>
                    <?php  } ?>
                </div>
            </div>-->
             <!--<div class="form-group">
                <label class="col-lg control-label must">所属门店</label>
                <div class="col-sm-9 col-xs-12">
                    <?php if( ce('store.saler' ,$item) ) { ?>
                      <?php  echo tpl_selector('storeid',array('text'=>'storename','preview'=>true,'type'=>'text',  'thumb'=>'avatar','placeholder'=>'门店名称','buttontext'=>'选择门店 ', 'items'=>$store,'url'=>webUrl('store/query')))?>
                      &lt;!&ndash;<span class='help-block'>店铺所属的门店，用于核销订单</span>&ndash;&gt;
                    <?php  } else { ?>
                       <div class='form-control-static'><?php  if(empty($store['storename'])) { ?>无所属门店<?php  } else { ?><?php  echo $store['storename'];?><?php  } ?></div>
                    <?php  } ?>
                </div>
            </div>-->

            <div class="form-group">
                <label class="col-lg control-label">状态</label>
                <div class="col-sm-9 col-xs-12">
                         <?php if( ce('store.saler' ,$item) ) { ?>
                    <label class='radio-inline'>
                        <input type='radio' name='status' value="1" <?php  if($item['status']==1) { ?>checked<?php  } ?> /> 启用
                    </label>
                    <label class='radio-inline'>
                        <input type='radio' name='status' value="0" <?php  if($item['status']==0) { ?>checked<?php  } ?> /> 禁用
                    </label>
                         <?php  } else { ?>
                          <div class='form-control-static'><?php  if($item['status']==1) { ?>启用<?php  } else { ?>禁用<?php  } ?></div>
                         <?php  } ?>
                </div>
            </div>
                
           <div class="form-group"></div>
            <div class="form-group">
                    <label class="col-lg control-label"></label>
                    <div class="col-sm-9 col-xs-12">
                           <?php if( ce('store.saler' ,$item) ) { ?>
                            <input type="submit" value="提交" class="btn btn-primary"  />
                        <?php  } ?>
                       <input type="button" name="back" onclick='history.back()' value="返回列表" class="btn btn-default" />
                    </div>
            </div>
    </form>
</div>

<script language='javascript'>

    $(document).ready(function () {
        $('#openid_text').focusout(function () {
            return false;
        })
    })

    function search_users() {
        $("#module-menus1").html("正在搜索....")
        $.get('<?php  echo webUrl("store/perm/role/query")?>', {
            keyword: $.trim($('#search-kwd1').val())
        }, function(dat){
            $('#module-menus1').html(dat);
        });
    }

    function select_role(o) {
        $("#userid").val(o.id);
        $("#user").val( o.rolename );
        $(".close2").click();
    }
</script>
 
<?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('_footer', TEMPLATE_INCLUDEPATH)) : (include template('_footer', TEMPLATE_INCLUDEPATH));?>
 