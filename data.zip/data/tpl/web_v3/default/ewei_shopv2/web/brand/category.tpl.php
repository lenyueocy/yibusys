<?php defined('IN_IA') or exit('Access Denied');?><?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('_header', TEMPLATE_INCLUDEPATH)) : (include template('_header', TEMPLATE_INCLUDEPATH));?>

<div class="page-header">
    当前位置：<span class="text-primary">品牌分类</span>
</div>
<div class="page-content">
    <div class="page-toolbar">
         <span class=''>
            <?php if(cv('brand.category.add' && $_W['merchid']==0)) { ?>
                <a class="btn btn-primary btn-sm" href="<?php  echo webUrl('brand/category/add')?>">添加品牌分类</a>
            <?php  } ?>
        </span>
    </div>
    <?php  if(count($list)>0) { ?>
    <table class="table table-hover table-responsive">
        <thead class="navbar-inner">
        <tr>
            <th style="width:50px;">ID</th>
            <th style='width:80px'>排序</th>
            <th>名称</th>
            <th style="width: 60px">状态</th>
            <?php  if($_W['merchid']==0) { ?>
            <th style="width: 75px;">操作</th>
            <?php  } ?>
        </tr>
        </thead>
        <tbody id="sort">
        <?php  if(is_array($list)) { foreach($list as $row) { ?>
        <tr>
            <td><?php  echo $row['id'];?></td>
            <td>
                <?php if(cv('live.category.edit' && $_W['merchid']==0)) { ?>
                <a href='javascript:;' data-toggle='ajaxEdit' data-href="<?php  echo webUrl('live/category/displayorder',array('id'=>$row['id']))?>" ><?php  echo $row['displayorder'];?></a>
                <?php  } else { ?>
                <?php  echo $row['displayorder'];?>
                <?php  } ?>
            </td>
            <td><?php  echo $row['name'];?></td>
            <td>
                <span class='label <?php  if($row['status']==1) { ?>label-primary<?php  } else { ?>label-default<?php  } ?>'
                <?php if(cv('brand.category.edit')) { ?>
                data-toggle='ajaxSwitch'
                data-switch-value='<?php  echo $row['status'];?>'
                data-switch-value0='0|禁用|label label-default|<?php  echo webUrl('brand/category/status',array('status'=>1,'id'=>$row['id']))?>'
                data-switch-value1='1|启用|label label-success|<?php  echo webUrl('brand/category/status',array('status'=>0,'id'=>$row['id']))?>'
                <?php  } ?>
                >
                <?php  if($row['status']==1) { ?>显示<?php  } else { ?>隐藏<?php  } ?></span>
            </td>
            <?php  if($_W['merchid']==0) { ?>
            <td style="text-align:left;">
                <?php if(cv('brand.category.view|brand.category.edit')) { ?>
                <a href="<?php  echo webUrl('brand/category/edit', array('id' => $row['id']))?>" class="btn  btn-sm btn-op btn-operation">
                                    <span data-toggle="tooltip" data-placement="top" title="" data-original-title="<?php if(cv('brand.category.edit')) { ?>修改<?php  } else { ?>查看<?php  } ?>">
                                        <?php if(cv('live.category.edit')) { ?>
                                            <i class='icow icow-bianji2'></i>
                                        <?php  } else { ?>
                                            <i class='icow icow-chakan-copy'></i>
                                        <?php  } ?>
                                   </span>
                </a>
                <?php  } ?>
                <?php if(cv('brand.category.delete')) { ?>
                <a data-toggle='ajaxRemove' href="<?php  echo webUrl('brand/category/delete', array('id' => $row['id']))?>"class="btn btn-sm btn-op btn-operation" data-confirm="确认删除此分类?" >
                                    <span data-toggle="tooltip" data-placement="top" title="" data-original-title="删除">
                                         <i class='icow icow-shanchu1'></i>
                                    </span>
                </a>
                <?php  } ?>
            </td>
            <?php  } ?>
        </tr>
        <?php  } } ?>
        </tbody>
    </table>
    <?php  echo $pager;?>
    <?php  } else { ?>
    <div class='panel panel-default'>
        <div class='panel-body' style='text-align: center;padding:30px;'>暂时没有任何品牌分类</div>
    </div>
    <?php  } ?>
</div>



<?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('_footer', TEMPLATE_INCLUDEPATH)) : (include template('_footer', TEMPLATE_INCLUDEPATH));?>

