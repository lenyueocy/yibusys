<?php defined('IN_IA') or exit('Access Denied');?><?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('_header', TEMPLATE_INCLUDEPATH)) : (include template('_header', TEMPLATE_INCLUDEPATH));?>


<div class="page-header">
	当前位置：<span class="text-primary"><?php  if(!empty($item['id'])) { ?>编辑<?php  } else { ?>添加<?php  } ?>医生 <small><?php  if(!empty($item['id'])) { ?>修改【<?php  echo $item['name'];?>】<?php  } ?></small></span>
</div>

<div class="page-content">
    <?php if(cv('brand.add')) { ?>
    <div class="page-sub-toolbar">
        <a class="btn btn-primary btn-sm" href="<?php  echo webUrl('brand/add')?>">添加科室</a>
    </div>
    <?php  } ?>
    <form <?php if( ce('brand.add' ,$item) ) { ?>action="" method="post"<?php  } ?> class="form-horizontal form-validate" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?php  echo $item['id'];?>" />

            <div class="form-group">
                <label class="col-lg control-label must">品牌名称</label>
                <div class="col-sm-9 col-xs-12">
                    <?php if( ce('brand.index' ,$item) ) { ?>
                    <input type="text" name="name" class="form-control" value="<?php  echo $item['name'];?>" data-rule-required='true'/>
                    <?php  } else { ?>
                    <div class='form-control-static'><?php  echo $item['name'];?></div>
                    <?php  } ?>
                </div>
            </div>

            <div class="form-group">
                <label class="col-lg control-label must">品牌logo</label>
                <div class="col-sm-9 col-xs-12">
                    <?php if( ce('brand' ,$item) ) { ?>
                    <?php  echo tpl_form_field_image('logo',$item['logo'])?>
                    <?php  } else { ?>
                    <?php  if(!empty($item['logo'])) { ?>
                    <a href='<?php  echo tomedia($item[' logo'])?>' target='_blank'>
                    <img src="<?php  echo tomedia($item['logo'])?>" style='width:100px;border:1px solid #ccc;padding:1px'/>
                    </a>
                    <?php  } ?>
                    <?php  } ?>
                </div>
            </div>

            <div class="form-group">
                <label class="col-lg control-label">品牌分类</label>
                <div class="col-sm-9 col-xs-12">
                    <?php if( ce('brand.index' ,$item) ) { ?>
                    <select id="cates" name='cate_id' class="form-control select2" style='width:605px;'  ><!--multiple=''-->
                        <option value="" selected >请选择品牌分类</option>
                        <?php  if(is_array($category)) { foreach($category as $c) { ?>
                        <option value="<?php  echo $c['id'];?>" <?php  if($c['id']==$item['cate_id']) { ?>selected<?php  } ?> ><?php  echo $c['name'];?></option>
                        <?php  } } ?>
                    </select>
                    <?php  } else { ?>
                    <div class='form-control-static'><?php  echo $item['cate_id'];?></div>
                    <?php  } ?>
                </div>
            </div>

            <div class="form-group">
                <label class="col-lg control-label">状态</label>
                <div class="col-sm-9 col-xs-12">
                         <?php if( ce('brand' ,$item) ) { ?>
                    <label class='radio-inline'>
                        <input type='radio' name='status' value="1" <?php  if($item['status']==1) { ?>checked<?php  } ?> /> 启用
                    </label>
                    <label class='radio-inline'>
                        <input type='radio' name='status' value="0" <?php  if($item['status']==0) { ?>checked<?php  } ?> /> 禁用
                    </label>
                         <?php  } else { ?>
                          <div class='form-control-static'><?php  if($item['status']==1) { ?>启用<?php  } else { ?>禁用<?php  } ?></div>
                         <?php  } ?>
                </div>
            </div>
                
           <div class="form-group"></div>
            <div class="form-group">
                    <label class="col-lg control-label"></label>
                    <div class="col-sm-9 col-xs-12">
                           <?php if( ce('brand' ,$item) ) { ?>
                            <input type="submit" value="提交" class="btn btn-primary"  />
                            
                        <?php  } ?>
                       <input type="button" name="back" onclick='history.back()' value="返回列表" class="btn btn-default" />
                    </div>
            </div>
    </form>
</div>

<script language='javascript'>

    $(document).ready(function () {
        $('#openid_text').focusout(function () {
            return false;
        })
    })

    function search_users() {
        $("#module-menus1").html("正在搜索....")
        $.get('<?php  echo webUrl("store/perm/role/query")?>', {
            keyword: $.trim($('#search-kwd1').val())
        }, function(dat){
            $('#module-menus1').html(dat);
        });
    }

    function select_role(o) {
        $("#userid").val(o.id);
        $("#user").val( o.rolename );
        $(".close2").click();
    }
</script>
 
<?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('_footer', TEMPLATE_INCLUDEPATH)) : (include template('_footer', TEMPLATE_INCLUDEPATH));?>
 