<?php defined('IN_IA') or exit('Access Denied');?><script type="text/javascript">
    location.href = '<?php  echo webUrl('exchange/history/statistics');?>';
</script>
<!--913702023503242914-->