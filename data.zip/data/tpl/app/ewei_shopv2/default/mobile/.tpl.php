<?php defined('IN_IA') or exit('Access Denied');?><?php (!empty($this) && $this instanceof WeModuleSite) ? (include $this->template('_header', TEMPLATE_INCLUDEPATH)) : (include template('_header', TEMPLATE_INCLUDEPATH));?>

<div class='fui-page  fui-page-current shop-index-page'>


	<div class="page_3" style="display: none">
		<div class="fangdatu">
			<div class="yundong"></div>
			<div class="yundong1"></div>
			<div class="yundong3"></div>
			<div class="wukgc">
				<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page/3.18.png" class="wz_318">
				<div class="zhong">
					<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page/zhogn.png"
						 class="zhong_img ">
					<div class="container">

					</div>
					<div class="jinruzhuye">进入主页</div>
				</div>
			</div>

		</div>

	</div>

	<!--    主页-->
	<div id="page_4" class="page_4" style="display: none">
		<div id="content4">
			<div class="cyaobaidezhgo"><img src="../addons/ewei_shopv2/template/mobile/default/static/images/page/2.png" style="width: 100%"></div>
			<div class="top">
				<div class="top_left">
					<img src="../addons/ewei_shopv2/template/mobile/default/static/images/page_4/top_left.png" alt="">
				</div>
				<div class="top_right box">
					<img src="../addons/ewei_shopv2/template/mobile/default/static/images/page_4/top_right.png" alt="">
					<span class="span"></span>
				</div>
			</div>
			<div id="nav">
				<ul>
					<li>
						<div id="nav-item1" class="nav-item ">
							<span>领导致辞</span>
						</div>
					</li>
					<li>
						<div id="nav-item2" class="nav-item ">
							<span>奏唱国歌</span>
						</div>
					</li>
					<li>
						<div id="nav-item3" class="nav-item ">
							<span>往昔回顾</span>
						</div>
					</li>
					<li>
						<div id="nav-item4" class="nav-item ">
							<span>主题歌曲</span>
						</div>
					</li>
					<li>
						<div id="nav-item5" class="nav-item ">
							<span>诗歌朗诵</span>
						</div>
					</li>
					<li>
						<div id="nav-item6" class="nav-item ">
							<span>有奖问答</span>
						</div>
					</li>
					<li>
						<div id="nav-item7" class="nav-item ">
							<span>留下感言</span>
						</div>
					</li>
					<li>
						<div id="nav-item8" class="nav-item ">
							<span>进博物馆</span>
						</div>
					</li>
					<li>
						<div id="nav-item9" class="nav-item ">
							<span>线上教育</span>
						</div>
					</li>
				</ul>
			</div>
		</div>
	</div>

	<!--    领导致辞-->
	<div class="page_5" style="display: none">
		<div class="content">
			<div class="yundong"></div>
			<div class="yundong1"></div>
			<div class="yundong3"></div>

			<div class="box">
				<div class="top">
					<div class="cs1">
						<div class="cs3">
							<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page_5/2.png"
								 class="rigangle">
						</div>
						<div class="cs2">
							<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page_5/318.png"
								 class="wuwanggc">
						</div>
					</div>


					<div class="css1">
						<div class="css3">
							<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page_5/1.png"
								 class="rigangle">
						</div>
						<div class="css2">
							<div class="leader_text">领导致辞</div>
						</div>
					</div>

					<div class="desc">稍稍停下腳步，认真地<span>回望历史</span>，<span>思索未来</span>。</div>
				</div>
				<div class="middle">
					<div class="title">中英街3.18警示日·领导致辞</div>
					<div class="vedio">
						<video style="background-color: rgb(0, 0, 0); width: 100%; height: 100%; display: block;"
							   webkit-playsinline="" x-webkit-airplay="" preload="auto" data-role="txp_video_tag"
							   src="https://apd-0f034469dcba3a1301a95a5dbe029d3e.v.smtcdns.com/om.tc.qq.com/Awa3B22IsFYC-hQHxrHIIFd6MzAaAdv8h4zZUORqsX0E/uwMROfz2r5zEIaQXGdGnC2dfDmafRkP9ujxgqKjuATzMrE-2/h0930o93gkz.mp4?sdtfrom=v1010&amp;guid=d89d6b0e0d4ded5236c5f855e30f5178&amp;vkey=0333DFD5AB943CFAFF4C3A347C75024B5E2BEB14E24D9E92AC58427EC2070642D67C4EC3F0683E57D543E8C4487E4E6116515709605C65CDCC1E818CA484413765EAEE4BC2ACE3D0E368B7A029474313E267C9293F309A3BA9B82FB2E4F921D64AB8AF9A6FB52BBDAF8EE11DE8BE46C45F546C472E315F2CF5432FA8B00DDF2B"></video>
					</div>
				</div>
				<div class="bottom"></div>
			</div>

			<div class="goindex">返回主页</div>
		</div>
	</div>


	<!--    奏唱国歌-->
	<div class="page_6" style="display: none">
		<div class="content">

			<div class="box">
				<div class="cs1">
					<div class="cs3">
						<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page_5/2.png"
							 class="rigangle">
					</div>
					<div class="cs2">
						<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page_5/318.png"
							 class="wuwanggc">
					</div>
				</div>


				<div class="css1">
					<div class="css3">
						<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page_5/1.png"
							 class="rigangle">
					</div>
					<div class="css2">
						<div class="leader_text">奏唱国歌</div>
					</div>
				</div>
				<div class="css1" style="margin-top: 3rem;">
					<div class="css3">
						<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page_5/1.png"
							 class="rigangle">
					</div>
					<div class="css2">
						<div class="leader_text" style=" background: #B39B77">少先队歌</div>
					</div>
				</div>

				<div class="middle">
					<div class="yatiao">
						<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page_6/yatiao0.png" alt="">
					</div>
					<img class="cipan"
						 src="/addons\ewei_shopv2\template\mobile\default\static\images\page_6/cipan.png"
						 alt="">
					<audio src="" id="music" hidden></audio>

				</div>


			</div>

			<div class="goindex">返回主页</div>
		</div>
	</div>

	<!--    往昔回顾-->
	<div class="page_7" style="display: none">
		<div class="content">
			<div class="yundong"></div>
			<div class="yundong1"></div>
			<div class="yundong3"></div>

			<div class="box">
				<div class="top">
					<div class="cs1">
						<div class="cs3">
							<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page_5/2.png"
								 class="rigangle">
						</div>
						<div class="cs2">
							<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page_5/318.png"
								 class="wuwanggc">
						</div>
					</div>


					<div class="css1">
						<div class="css3">
							<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page_5/1.png"
								 class="rigangle">
						</div>
						<div class="css2">
							<div class="leader_text">往昔回顾</div>
						</div>
					</div>

					<div class="desc">稍稍停下腳步，认真地<span>回望历史</span>，<span>思索未来</span>。</div>
				</div>
				<div class="middle">
					<div class="title">中英街3.18警示日纪念专题片</div>
					<div class="vedio">
						<video style="background-color: rgb(0, 0, 0); width: 100%; height: 100%; display: block;"
							   webkit-playsinline="" x-webkit-airplay="" preload="auto" data-role="txp_video_tag"
							   src="https://apd-0f034469dcba3a1301a95a5dbe029d3e.v.smtcdns.com/om.tc.qq.com/Awa3B22IsFYC-hQHxrHIIFd6MzAaAdv8h4zZUORqsX0E/uwMROfz2r5zEIaQXGdGnC2dfDmafRkP9ujxgqKjuATzMrE-2/h0930o93gkz.mp4?sdtfrom=v1010&amp;guid=d89d6b0e0d4ded5236c5f855e30f5178&amp;vkey=0333DFD5AB943CFAFF4C3A347C75024B5E2BEB14E24D9E92AC58427EC2070642D67C4EC3F0683E57D543E8C4487E4E6116515709605C65CDCC1E818CA484413765EAEE4BC2ACE3D0E368B7A029474313E267C9293F309A3BA9B82FB2E4F921D64AB8AF9A6FB52BBDAF8EE11DE8BE46C45F546C472E315F2CF5432FA8B00DDF2B"></video>
					</div>
				</div>
				<div class="bottom">

					<div class="title">中英街3.18警示日历届活动回顾</div>
					<div class="container">
						<div class="swiper-container" style="margin-top: 0.5rem;">
							<div class="swiper-wrapper">
								<div class="swiper-slide  tup">
									<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page/01.jpg" alt="" style="    width: 10rem;
    height: 8rem;" >3
								</div>
								<div class="swiper-slide  tup">
									<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page/02.jpg" alt="" style="    width: 10rem;
    height: 8rem;">2
								</div>
								<div class="swiper-slide  tup">
									<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page/03.jpg" alt="" style="    width: 10rem;
    height: 8rem;">4
								</div>
								<div class="swiper-slide  tup">
									<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page/04.jpg" alt="" style="    width: 10rem;
    height: 8rem;">5
								</div>
								<div class="swiper-slide  tup">
									<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page/05.jpg" alt="" style="    width: 10rem;
    height: 8rem;">1
								</div>
							</div>

							<div class="swiper-button-prev"></div>
							<div class="swiper-button-next"></div>
						</div>
					</div>

				</div>
			</div>

			<div class="goindex">返回主页</div>
		</div>
	</div>


	<!--    主题歌曲-->
	<div class="page_8" style="display: none">
		<div class="content">
			<div class="yundong"></div>
			<div class="yundong1"></div>
			<div class="yundong3"></div>

			<div class="box">
				<div class="top">
					<div class="cs1">
						<div class="cs3">
							<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page_5/2.png"
								 class="rigangle">
						</div>
						<div class="cs2">
							<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page_5/318.png"
								 class="wuwanggc">
						</div>
					</div>


					<div class="css1">
						<div class="css3">
							<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page_5/1.png"
								 class="rigangle">
						</div>
						<div class="css2">
							<div class="leader_text">主题歌曲</div>
						</div>
					</div>

					<div class="desc">稍稍停下腳步，认真地<span>回望历史</span>，<span>思索未来</span>。</div>
				</div>
				<div class="middle">
					<div class="title">中英街3.18警示日纪念主题曲</div>
					<div class="vedio">
						<video style="background-color: rgb(0, 0, 0); width: 100%; height: 100%; display: block;"
							   webkit-playsinline="" x-webkit-airplay="" preload="auto" data-role="txp_video_tag"
							   src="https://apd-0f034469dcba3a1301a95a5dbe029d3e.v.smtcdns.com/om.tc.qq.com/Awa3B22IsFYC-hQHxrHIIFd6MzAaAdv8h4zZUORqsX0E/uwMROfz2r5zEIaQXGdGnC2dfDmafRkP9ujxgqKjuATzMrE-2/h0930o93gkz.mp4?sdtfrom=v1010&amp;guid=d89d6b0e0d4ded5236c5f855e30f5178&amp;vkey=0333DFD5AB943CFAFF4C3A347C75024B5E2BEB14E24D9E92AC58427EC2070642D67C4EC3F0683E57D543E8C4487E4E6116515709605C65CDCC1E818CA484413765EAEE4BC2ACE3D0E368B7A029474313E267C9293F309A3BA9B82FB2E4F921D64AB8AF9A6FB52BBDAF8EE11DE8BE46C45F546C472E315F2CF5432FA8B00DDF2B"></video>
					</div>
				</div>
				<div class="bottom"></div>
			</div>

			<div class="goindex">返回主页</div>
		</div>
	</div>

	<!--    诗歌朗诵-->
	<div class="page_9" style="display: none">
		<div class="content">
			<div class="yundong"></div>
			<div class="yundong1"></div>
			<div class="yundong3"></div>

			<div class="box">
				<div class="top">
					<div class="cs1">
						<div class="cs3">
							<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page_5/2.png"
								 class="rigangle">
						</div>
						<div class="cs2">
							<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page_5/318.png"
								 class="wuwanggc">
						</div>
					</div>


					<div class="css1">
						<div class="css3">
							<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page_5/1.png"
								 class="rigangle">
						</div>
						<div class="css2">
							<div class="leader_text">诗歌朗诵</div>
						</div>
					</div>

					<div class="desc">稍稍停下腳步，认真地<span>回望历史</span>，<span>思索未来</span>。</div>
				</div>
				<div class="middle">
					<div class="title">中英街3.18警示日钟鸣朗诵</div>
					<div class="vedio">
						<video style="background-color: rgb(0, 0, 0); width: 100%; height: 100%; display: block;"
							   webkit-playsinline="" x-webkit-airplay="" preload="auto" data-role="txp_video_tag"
							   src="https://apd-0f034469dcba3a1301a95a5dbe029d3e.v.smtcdns.com/om.tc.qq.com/Awa3B22IsFYC-hQHxrHIIFd6MzAaAdv8h4zZUORqsX0E/uwMROfz2r5zEIaQXGdGnC2dfDmafRkP9ujxgqKjuATzMrE-2/h0930o93gkz.mp4?sdtfrom=v1010&amp;guid=d89d6b0e0d4ded5236c5f855e30f5178&amp;vkey=0333DFD5AB943CFAFF4C3A347C75024B5E2BEB14E24D9E92AC58427EC2070642D67C4EC3F0683E57D543E8C4487E4E6116515709605C65CDCC1E818CA484413765EAEE4BC2ACE3D0E368B7A029474313E267C9293F309A3BA9B82FB2E4F921D64AB8AF9A6FB52BBDAF8EE11DE8BE46C45F546C472E315F2CF5432FA8B00DDF2B"></video>
					</div>
				</div>
				<div class="bottom"></div>
			</div>

			<div class="goindex">返回主页</div>
		</div>
	</div>


	<!--    有奖问答-->
	<div class="page_10" style="display: none">
		<div class="content">
			<div class="yundong"></div>
			<div class="yundong1"></div>
			<div class="yundong3"></div>

			<div class="box">
				<div class="top">
					<div class="top_border_bottom">
						<div class="top_right">
							<div class="top_right_top">
								<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page_5/2.png"
									 class="rigangle">
							</div>
							<div class="top_right_bottom">
								<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page_5/318.png"
									 class="wuwanggc">
							</div>
						</div>


						<div class="top_left">
							<div class="top_left_top">
								<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page_5/1.png"
									 class="rigangle">
							</div>
							<div class="top_left_bottom">
								<div class="leader_text">诗歌朗诵</div>
							</div>
						</div>

						<div class="desc">稍稍停下腳步，认真地<span>回望历史</span>，<span>思索未来</span>。</div>
					</div>
				</div>
				<div class="bottom">
					<div><span>下一题</span></div>
				</div>

			</div>

			<div class="goindex">返回主页</div>
		</div>
	</div>


	<!--    有奖问答-->
	<div class="page_10" style="display: none">
		<div class="content">
			<div class="yundong"></div>
			<div class="yundong1"></div>
			<div class="yundong3"></div>

			<div class="box">
				<div class="top">
					<div class="top_right">
						<div class="top_right_top">
							<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page_5/2.png"
								 class="rigangle">
						</div>
						<div class="top_right_bottom">
							<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page_5/318.png"
								 class="wuwanggc">
						</div>
					</div>


					<div class="top_left">
						<div class="top_left_top">
							<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page_5/1.png"
								 class="rigangle">
						</div>
						<div class="top_left_bottom">
							<div class="leader_text">有奖答题</div>
						</div>
					</div>
					<div class="desc">稍稍停下腳步，认真地<span>回望历史</span>，<span>思索未来</span>。</div>
				</div>
				<div class="middle content1">
					<div class="middle_top">
						<div class="swiper-container">
							<div class="swiper-wrapper">
								<div class="swiper-slide ">
									<div class="subj">
										<div class="title">1.我国教育家()特别重视儿童对知识的探索与实际运用能力的培养,提出了“做中学做中教”的方法论?</div>
										<div class="answer">
											<div class="answer-item"><input type="radio" name="subj1"> A.朱智贤</div>
											<div class="answer-item"><input type="radio" name="subj1"> B.陶行知</div>
											<div class="answer-item"><input type="radio" name="subj1"> C.C张雪门D</div>
											<div class="answer-item"><input type="radio" name="subj1"> D.陈鹤琴</div>
										</div>
									</div>
								</div>
								<div class="swiper-slide ">
									<div class="subj">
										<div class="title">2.我国教育家()特别重视儿童对知识的探索与实际运用能力的培养,提出了“做中学做中教”的方法论?</div>
										<div class="answer">
											<div class="answer-item"><input type="radio" name="subj1"> A.朱智贤</div>
											<div class="answer-item"><input type="radio" name="subj1"> B.陶行知</div>
											<div class="answer-item"><input type="radio" name="subj1"> C.C张雪门D</div>
											<div class="answer-item"><input type="radio" name="subj1"> D.陈鹤琴</div>
										</div>
									</div>
								</div>
								<div class="swiper-slide ">
									<div class="subj">
										<div class="title">3.我国教育家()特别重视儿童对知识的探索与实际运用能力的培养,提出了“做中学做中教”的方法论?</div>
										<div class="answer">
											<div class="answer-item"><input type="radio" name="subj1"> A.朱智贤</div>
											<div class="answer-item"><input type="radio" name="subj1"> B.陶行知</div>
											<div class="answer-item"><input type="radio" name="subj1"> C.C张雪门D</div>
											<div class="answer-item"><input type="radio" name="subj1"> D.陈鹤琴</div>
										</div>
									</div>
								</div>
								<div class="swiper-slide ">
									<div class="subj">
										<div class="title">4.我国教育家()特别重视儿童对知识的探索与实际运用能力的培养,提出了“做中学做中教”的方法论?</div>
										<div class="answer">
											<div class="answer-item"><input type="radio" name="subj1"> A.朱智贤</div>
											<div class="answer-item"><input type="radio" name="subj1"> B.陶行知</div>
											<div class="answer-item"><input type="radio" name="subj1"> C.C张雪门D</div>
											<div class="answer-item"><input type="radio" name="subj1"> D.陈鹤琴</div>
										</div>
									</div>
								</div>

							</div>
						</div>
					</div>
					<div class="middle_bottom">
						<div id="btn2" class="subj-btn">
							<span class="next-subj">下一题</span>
						</div>
						<div  class="subj-btn submit" style="display: none">
							<span class="next-subj">提交</span>
						</div>
					</div>
				</div>

				<div class="middle content2" style="display: none">
					<div class="draw_middle_top">
						<div class="draw_box">
							<img class="draw" src="/addons\ewei_shopv2\template\mobile\default\static\images\page/zhuanpan.png" alt="">
							<div class="draw_start_btn"><img src="/addons\ewei_shopv2\template\mobile\default\static\images\page/zhibiao.png" alt=""></div>
						</div>
						<!--                        <div class="turnplate">-->
						<!--                            <canvas class="item" id="wheelcanvas" width="422px" height="422px"></canvas>-->
						<!--                            <img class="pointer" src="images/turnplate-pointer.png"/>-->
						<!--                        </div>-->
					</div>
					<div class="middle_bottom">
						<div class="draw_tip">恭喜你全部答对了,点击转盘参加抽奖!</div>
						<div class="draw_btn">
							<span class="next-subj">抽奖说明</span>
						</div>
					</div>
				</div>
			</div>

			<div class="goindex">返回主页</div>
		</div>
	</div>

	<!--    留言板-->
	<div class="page_11" style="display: none">
		<div class="content">
			<div class="yundong"></div>
			<div class="yundong1"></div>
			<div class="yundong3"></div>

			<div class="box">
				<div class="top">
					<div class="top_right">
						<div class="top_right_top">
							<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page_5/2.png"
								 class="rigangle">
						</div>
						<div class="top_right_bottom">
							<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page_5/318.png"
								 class="wuwanggc">
						</div>
					</div>


					<div class="top_left">
						<div class="top_left_top">
							<img src="/addons\ewei_shopv2\template\mobile\default\static\images\page_5/1.png"
								 class="rigangle">
						</div>
						<div class="top_left_bottom">
							<div class="leader_text">留下感言</div>
						</div>
					</div>
					<div class="desc">稍稍停下腳步，认真地<span>回望历史</span>，<span>思索未来</span>。</div>
				</div>
				<div class="middle">
					<div class="message_box">
						<div><textarea name="" class="message_board" id="" cols="30" rows="10"></textarea>
							<div>
								<button>提交</button>
							</div>
						</div>
					</div>
					<div class="middle_top">
						<div class="swiper-container">

							<div class="swiper-wrapper">
								<div class="swiper-slide">
									<div class="board">
										<div class="message">勿忘国耻，振兴中华！！！铭记历史不是为了延续仇恨，而是为了更强大的未来</div>
										<div class="info">
											领导职务以及名称 2020.3.11 10:08
										</div>
									</div>
									<div class="board">
										<div class="message">勿忘国耻，振兴中华！！！铭记历史不是为了延续仇恨，而是为了更强大的未来</div>
										<div class="info">
											领导职务以及名称 2020.3.11 10:08
										</div>
									</div>
									<div class="board">
										<div class="message">勿忘国耻，振兴中华！！！铭记历史不是为了延续仇恨，而是为了更强大的未来</div>
										<div class="info">
											领导职务以及名称 2020.3.11 10:08
										</div>
									</div>
									<div class="board">
										<div class="message">勿忘国耻，振兴中华！！！铭记历史不是为了延续仇恨，而是为了更强大的未来</div>
										<div class="info">
											领导职务以及名称 2020.3.11 10:08
										</div>
									</div>
								</div>
							</div>
							<div class="swiper-scrollbar"></div>
						</div>
					</div>

				</div>

				<div class="goindex">返回主页</div>
			</div>
		</div>

		<script language='javascript'>
			require(['biz/index'], function (modal) {
				modal.init({});
			});
		</script>


		<?php (!empty($this) && $this instanceof WeModuleSite) ? (include $this->template('_footer', TEMPLATE_INCLUDEPATH)) : (include template('_footer', TEMPLATE_INCLUDEPATH));?>