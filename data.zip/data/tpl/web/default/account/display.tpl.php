<?php defined('IN_IA') or exit('Access Denied');?><?php (!empty($this) && $this instanceof WeModuleSite || 0) ? (include $this->template('common/header', TEMPLATE_INCLUDEPATH)) : (include template('common/header', TEMPLATE_INCLUDEPATH));?>
<div class="account-display-page" id="js-account-display" ng-controller="AccountDisplay" ng-cloak>
	<div class="panel-cut panel">
		<div class="panel-body">
			<div class="search-box">
				<select class="we7-margin-right" ng-model="chenckNav" ng-change="changes()">
					<option value="{{item.name}}" ng-repeat="item in nav_top_fold" ng-bind="item.title"></option>
				</select>
				<select name="" class="select-letter we7-margin-right"  ng-init="letter = '<?php echo $_GPC['letter'] ? $_GPC['letter'] : '全部'?>'" ng-model="letter" ng-change="searchModule(letter)">
					<option value="{{item == '按字母筛选(全部)' ? '全部' : item}}"  ng-repeat="item in alphabet" ng-bind="item"></option>
				</select>
				<form class="search-form" action="./index.php" method="get">
					<input type="hidden" name="c" value="account">
					<input type="hidden" name="a" value="display">
					<input type="hidden" name="do" value="display" ng-if="type == 'all'">
					<input type="hidden" name="type" value="{{type}}">
					<input type="hidden" name="title" value="{{title}}">
					<input type="text" name="letter" ng-model="activeLetter" ng-style="{'display': 'none'}">
					<div class="input-group">
						<input type="text" class="form-control" name="keyword" value="<?php  echo $_GPC['keyword'];?>" placeholder="请输入平台名称">
						<span class="input-group-btn"><button class="btn btn-default button"><i class="fa fa-search"></i></button></span>
					</div>
				</form>
				
				<div class="creat" ng-switch="type">
					<a ng-switch-when="all" href="javascript:;" data-toggle="modal" data-target="#owner-modal" class="btn btn-primary">新增平台</a>
	
					<?php  if(!empty($account_info['account_limit']) && (!empty($account_info['founder_account_limit']) && $_W['user']['owner_uid'] || empty($_W['user']['owner_uid'])) || $_W['isfounder'] && !user_is_vice_founder()) { ?>
					<a ng-switch-when="account" href="./index.php?c=account&a=post-step" class="btn btn-primary">
						新增公众号
					</a>
					<?php  } ?>
	
					<?php  if(!empty($account_info['wxapp_limit']) && (!empty($account_info['founder_wxapp_limit']) && $_W['user']['owner_uid'] || empty($_W['user']['owner_uid'])) || $_W['isfounder'] && !user_is_vice_founder()) { ?>
					<a ng-switch-when="wxapp" href="<?php  echo url('wxapp/post/design_method')?>" class="btn btn-primary">新建微信小程序</a>
					<?php  } ?>
	
					<?php  if(!empty($account_info['webapp_limit']) && (!empty($account_info['founder_webapp_limit']) && $_W['user']['owner_uid'] || empty($_W['user']['owner_uid'])) || $_W['isfounder'] && !user_is_vice_founder()) { ?>
					<a ng-switch-when="webapp" href="<?php  echo url('account/create', array('sign' => 'webapp'))?>" class="btn btn-primary">
						新增PC
					</a>
					<?php  } ?>
	
					<?php  if(!empty($account_info['phoneapp_limit']) && (!empty($account_info['founder_phoneapp_limit']) && $_W['user']['owner_uid'] || empty($_W['user']['owner_uid'])) || $_W['isfounder'] && !user_is_vice_founder()) { ?>
					<a ng-switch-when="phoneapp" href="<?php  echo url('account/create', array('sign' => 'phoneapp'))?>" class="btn btn-primary">新建APP</a>
					<?php  } ?>
	
					<?php  if(!empty($account_info['xzapp_limit']) && (!empty($account_info['founder_xzapp_limit']) && $_W['user']['owner_uid'] || empty($_W['user']['owner_uid'])) || $_W['isfounder'] && !user_is_vice_founder()) { ?>
					<a ng-switch-when="xzapp" href="<?php  echo url('xzapp/post-step')?>" class="btn btn-primary">新建熊掌号</a>
					<?php  } ?>
	
					<?php  if(!empty($account_info['aliapp_limit']) && (!empty($account_info['founder_aliapp_limit']) && $_W['user']['owner_uid'] || empty($_W['user']['owner_uid'])) || $_W['isfounder'] && !user_is_vice_founder()) { ?>
					<a ng-switch-when="aliapp" href="<?php  echo url('account/create', array('sign' => 'aliapp'))?>" class="btn btn-primary">新建支付宝小程序</a>
					<?php  } ?>
					<?php  if(!empty($account_info['baiduapp_limit']) && (!empty($account_info['founder_baiduapp_limit']) && $_W['user']['owner_uid'] || empty($_W['user']['owner_uid'])) || $_W['isfounder'] && !user_is_vice_founder()) { ?>
					<a ng-switch-when="baiduapp" href="<?php  echo url('account/create', array('sign' => 'baiduapp'))?>" class="btn btn-primary">新建百度小程序</a>
					<?php  } ?>
					<?php  if(!empty($account_info['toutiaoapp_limit']) && (!empty($account_info['founder_toutiaoapp_limit']) && $_W['user']['owner_uid'] || empty($_W['user']['owner_uid'])) || $_W['isfounder'] && !user_is_vice_founder()) { ?>
					<a ng-switch-when="toutiaoapp" href="<?php  echo url('account/create', array('sign' => 'toutiaoapp'))?>" class="btn btn-primary">新建头条小程序</a>
					<?php  } ?>
				</div>
				
	
				
			</div>
			<div class="account-display-list" infinite-scroll='loadMore()' infinite-scroll-disabled='busy' infinite-scroll-distance='0' infinite-scroll-use-document-bottom="true">
				<div class="item" ng-repeat="detail in list|orderBy:'endtime_status'">
					<div class="item-box">
						<?php  if(!user_is_founder($_W['uid'])) { ?>
						<div class="auth-type">
							<i class="wi wi" ng-if="detail.user_role == 'owner'">主管理员</i>
							<i class="wi wi" ng-if="detail.user_role == 'manager'">管理员</i>
							<i class="wi wi" ng-if="detail.user_role == 'operator'">操作员</i>
							<i class="wi wi" ng-if="detail.user_role == 'clerk'">店员</i>
						</div>
						<?php  } ?>
						<a class="info" href="{{detail.switchurl}}&type={{detail.type}}">
							<img src="{{detail.logo || ''}}" class="account-img logo" alt="">
							<div class="name " >
								<div ng-bind="detail.name" class="text-over">1</div>
								<div class="type" ng-if="detail.type_sign == 'account'">
									<span>微信公众号</span>
								</div>
								<div class="type" ng-if="detail.type_sign == 'account'">
									<span ng-if="detail.level == 1">普通订阅号</span>
									<span ng-if="detail.level == 2">普通服务号</span>
									<span ng-if="detail.level == 3">认证订阅号</span>
									<span ng-if="detail.level == 4">认证服务号</span>
								</div>
								<div class="type" ng-if="detail.type_sign == 'wxapp'">
									<span>微信小程序</span>
								</div>
								<div class="type" ng-if="detail.type_sign == 'webapp'">
									<span>PC</span>
								</div>
								<div class="type" ng-if="detail.type_sign == 'phoneapp'">
									<span>APP</span>
								</div>
								<div class="type" ng-if="detail.type_sign == 'xzapp'">
									<span>熊掌号</span>
								</div>
								<div class="type" ng-if="detail.type_sign == 'aliapp'">
									<span>支付宝小程序</span>
								</div>
								<div class="type" ng-if="detail.type_sign == 'baiduapp'">
									<span>百度小程序</span>
								</div>
								<div class="type" ng-if="detail.type_sign == 'toutiaoapp'">
									<span>百度小程序</span>
								</div>
								<div class="type" ng-if="detail.support_version">
									<span>版本：{{detail.current_version.version}}</span>
								</div>
							</div>
							
							<div class="tip" ng-if="detail.endtime_status">
								<i class="wi wi-info">已到期</i>
							</div>
						</a>
						<div class="action">
							<a href="javascript:void(0);" class="action-up" ng-click="stick(detail.uniacid, detail.type)" data-toggle="tooltip" data-placement="bottom" data-title="置顶"><i class="wi wi-stick-sign"></i></a>
							<a class="action-account" href="{{detail.switchurl}}">
								<i class="wi wi-denglu"></i> 进入
							</a>
							<div class="action-cut">
								<a href="<?php  echo url('miniapp/version/display')?>&uniacid={{detail.uniacid}}" class="cut-btn" ng-if="detail.support_version" data-toggle="tooltip" data-placement="bottom" data-title="切换版本">
									<i class="wi wi-changing-over"></i>
								</a>
							</div>
						</div>
					</div>
				</div>
	
			</div>
		
			<!--新建弹窗-->
			<div class="modal fade modal-type" tabindex="-1" role="dialog" id="owner-modal">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header clearfix">
							新建
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						</div>
						<div class="modal-body">
							<div class="type-list">
								<?php  if(!empty($account_info['account_limit']) && (!empty($account_info['founder_account_limit']) && $_W['user']['owner_uid'] || empty($_W['user']['owner_uid'])) || $_W['isfounder'] && !user_is_vice_founder()) { ?>
								<a class="item" href="./index.php?c=account&a=post-step">
									<i class="wi wi-wx-circle"></i>
									<div class="name">新建公众号</div>
									<div class="mark">
										去新建
									</div>
								</a>
								<?php  } ?>
	
								<?php  if(!empty($account_info['wxapp_limit']) && (!empty($account_info['founder_wxapp_limit']) && $_W['user']['owner_uid'] || empty($_W['user']['owner_uid'])) || $_W['isfounder'] && !user_is_vice_founder()) { ?>
								<a href="<?php  echo url('wxapp/post/design_method')?>" class="item">
									<i class="wi wi-wxapp"></i>
									<div class="name">新建微信小程序</div>
									<div class="mark">
										去新建
									</div>
								</a>
								<?php  } ?>
	
								<?php  if(!empty($account_info['webapp_limit']) && (!empty($account_info['founder_webapp_limit']) && $_W['user']['owner_uid'] || empty($_W['user']['owner_uid'])) || $_W['isfounder'] && !user_is_vice_founder()) { ?>
								<a href="<?php  echo url('account/create', array('sign' => 'webapp'))?>" class="item">
									<i class="wi wi-pc-circle"></i>
									<div class="name">新建PC</div>
									<div class="mark">
										去新建
									</div>
								</a>
								<?php  } ?>
	
								<?php  if(!empty($account_info['phoneapp_limit']) && (!empty($account_info['founder_phoneapp_limit']) && $_W['user']['owner_uid'] || empty($_W['user']['owner_uid'])) || $_W['isfounder'] && !user_is_vice_founder()) { ?>
								<a href="<?php  echo url('account/create', array('sign' => 'phoneapp'))?>" class="item">
									<i class="wi wi-app"></i>
									<div class="name">新建APP</div>
									<div class="mark">
										去新建
									</div>
								</a>
								<?php  } ?>
	
								<?php  if(!empty($account_info['xzapp_limit']) && (!empty($account_info['founder_xzapp_limit']) && $_W['user']['owner_uid'] || empty($_W['user']['owner_uid'])) || $_W['isfounder'] && !user_is_vice_founder()) { ?>
								<a href="<?php  echo url('xzapp/post-step')?>" class="item">
									<i class="wi wi-xzapp"></i>
									<div class="name">新建熊掌号</div>
									<div class="mark">
										去新建
									</div>
								</a>
								<?php  } ?>
	
								<?php  if(!empty($account_info['aliapp_limit']) && (!empty($account_info['founder_aliapp_limit']) && $_W['user']['owner_uid'] || empty($_W['user']['owner_uid'])) || $_W['isfounder'] && !user_is_vice_founder()) { ?>
								<a href="<?php  echo url('account/create', array('sign' => 'aliapp'))?>" class="item">
									<i class="wi wi-aliapp"></i>
									<div class="name">新建支付宝小程序</div>
									<div class="mark">
										去新建
									</div>
								</a>
								<?php  } ?>
	
								<?php  if(!empty($account_info['baiduapp_limit']) && (!empty($account_info['founder_baiduapp_limit']) && $_W['user']['owner_uid'] || empty($_W['user']['owner_uid'])) || $_W['isfounder'] && !user_is_vice_founder()) { ?>
								<a href="<?php  echo url('account/create', array('sign' => 'baiduapp'))?>" class="item">
									<i class="wi wi-aliapp"></i>
									<div class="name">新建百度小程序</div>
									<div class="mark">
										去新建
									</div>
								</a>
								<?php  } ?>
	
								<?php  if(!empty($account_info['toutiaoapp_limit']) && (!empty($account_info['founder_toutiaoapp_limit']) && $_W['user']['owner_uid'] || empty($_W['user']['owner_uid'])) || $_W['isfounder'] && !user_is_vice_founder()) { ?>
								<a href="<?php  echo url('account/create', array('sign' => 'toutiaoapp'))?>" class="item">
									<i class="wi wi-aliapp"></i>
									<div class="name">新建头条小程序</div>
									<div class="mark">
										去新建
									</div>
								</a>
								<?php  } ?>
							</div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default"  data-dismiss="modal">取消</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script>
	angular.module('accountApp').value('config', {
		'nav_top_fold': <?php echo !empty($nav_top_fold) ? json_encode($nav_top_fold) : 'null'?>,
		'welcomeUrl': '<?php  echo url('home/welcome/');?>',
		'accountUrl': '<?php  echo url('account/display/')?>',
		'list' : <?php echo !empty($list) ? json_encode($list) : 'null'?>,
		'type' : "<?php  echo $type;?>",
		'title' : "<?php  echo $title;?>",
		'keyword' : "<?php  echo $keyword;?>",
		'letter' : "<?php  echo $letter;?>",
		'founder_id' : "<?php  echo $founder_id;?>",
		'total' : '<?php  echo $total;?>',
		'links' : {
			'changeType' : "<?php  echo url('account/display')?>",
			'rank' : "<?php  echo url('account/display/rank')?>",
			'welcome' : "<?php  echo url('home/welcome/add_welcome')?>",
			'wxapp_more_version' : "<?php  echo url('wxapp/version/display')?>",
			'aliapp_more_version' : "<?php  echo url('miniapp/version/display')?>",
			'baiduapp_more_version' : "<?php  echo url('miniapp/version/display')?>",
			'toutiaoapp_more_version' : "<?php  echo url('miniapp/version/display')?>",
			'phoneapp_more_version' : "<?php  echo url('phoneapp/version/display')?>"
		},
		'scrollUrl' : "<?php  echo url('account/display', array('type'=>$type))?>"
	});
	angular.bootstrap($('#js-account-display'), ['accountApp']);
</script>

<?php (!empty($this) && $this instanceof WeModuleSite || 0) ? (include $this->template('common/footer', TEMPLATE_INCLUDEPATH)) : (include template('common/footer', TEMPLATE_INCLUDEPATH));?>